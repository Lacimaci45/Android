import Hatter from './bg2.jpg';

function Main() {
  return (
    <section className="p-4 bg-no-repeat bg-fixed bg-center bg-lime-200 h-screen" style={{backgroundImage:`url(${Hatter})`}}>
    </section>
  );
}

export default Main;