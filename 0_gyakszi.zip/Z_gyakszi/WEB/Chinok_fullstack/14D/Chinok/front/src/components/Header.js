
function Header() {
  return (
    <h1 className="text-5xl text-center bg-neutral-200 p-4">Chinook Adatbázis</h1>
  )
}

export default Header