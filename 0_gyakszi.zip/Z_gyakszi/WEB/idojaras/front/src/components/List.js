import Listaelem from "./Listaelem";

function List({lista}){
    return (
        <div>
            {lista.map((elem)=>(
                <Listaelem elem={elem} />
            ))}
        </div>
    );
}

export default List;