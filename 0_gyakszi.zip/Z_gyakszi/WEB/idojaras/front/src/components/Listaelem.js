import Listaelemreszlet from "./Listaelemreszlet";
import {useState} from 'react';

function Listaelem({elem}){
    const[isReszlet,setIsReszlet]=useState(false);
    return(
        <div onClick={()=>{setIsReszlet(!isReszlet)}}>

            {
               isReszlet ? 
               <div><p>{elem.ev}:{elem.honap}:{elem.nap} {elem.ora}</p><Listaelemreszlet elem={elem} /></div> : <p>{elem.ev}:{elem.honap}:{elem.nap} {elem.ora}</p>
            }
            
        </div>
    );
}
export default Listaelem;