function Header({cim,udvozles}){
    return (
        <div>
            <h1>{cim}</h1>
            <h2>{udvozles}</h2>
        </div>
    );
}

export default Header;