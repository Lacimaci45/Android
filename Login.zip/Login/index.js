//Login backend projekt

//npm start --> backend indítás -->ctrl+c --> y --> backend leállítás 
//csomagok behívása-importálása
// új csomagok parancsai ---> npm i ejs, npm i bcrypt, npm i passport, npm i express-flash,  npm i express-session, npm i passport-local

//express csomag beszúrása
const express=require('express');
//cors csomag beszúrása
const cors=require('cors');
//mysql csomag beszúrása
const mysql=require('mysql');
//jelszó csomag behúzása
const bcrypt=require('bcrypt');
//dbrepo behívása a Promise-okkal
const {reg}=require('.dbrepo.js');
//passport behívása
const passport=require('passport');
//flash behívása
const flash=require('express-flash');
//session behívása
const session=require('express-session');
//passport-config.js behívása
const initializePassport=require('./passport-config');

//mysql adabázis kapcsolat létrehozása
const conn=mysql.createConnection(
    {
        host:"localhost",
        user:"root",
        password:"",
        database:"userdb2022"
    }

)

// express csomagból lesz az app működtetve
const app=express();
//app. amit haszmál az app 
app.use(cors());
// bodyban lévő adatok elérése app.use.....
app.use(express.json());
app.use(express.urlencoded({extended:true}));
//EJS (belső ExternalJavaScript) behúzása || telepítése ---> npm i ejs --> egy külön mappába célszerű a .ejs file-oket létrehozni
app.set('view-engine','ejs');
//passport és session app behúzása
initializePassport(passport,conn);
app.use(session({
    secret:"titok",
    resave:false,
    saveUninitialized:false,

}));
app.use(passport.initialize());
app.use(passport.session());

//Authentication megírása 2db function-al
function checkAuth(res,req,next){
    if(req.isAuthenticated()){
        return next();
    }
    res.redirect('/login');
}

function checkNotAuth(res,req,next){
    if(req.isAuthenticated()){
        return res.redirect('/');
    }
    next();
}

//szerver port + üzenet
app.listen(8000,()=>{console.log("Fut a szerver")});



//végpontok +  ejs file amiből dolgozik a res.render-el /res.send helyett!

//EJS rendszer üzenet
app.get('/',checkAuth,(req,res)=>{
    res.render("index.ejs",{user:", Laci az admin"});
});

//URL code localhost:8000/login
app.get('/login',checkNotAuth,(req,res)=>{
    res.render('login.ejs');
});

//URL code localhost:8000/reg
app.get('/reg',checkNotAuth,(req,res)=>{
    res.render('reg.ejs');
});

//Authenticate passport megírása
app.post('/login',checkNotAuth,passport.authenticate('local',
{
    successRedirect:'/',
    failureRedirect:'/login',
    failureFlash:true,

}
));


//adatfelvevő beillesztéssel végpont --> npm i bcrypt --> jelszó csomag telepító HASH-el működik
app.post('/reg',checkNotAuth,async (req,res)=>{
    try{
        const hashedPassword=await bcrypt.hash(req.body.password,10);
        const newUser={
            email:req.body.email,
            userename:req.body.userename,
            password:hashedPassword,
        }

        reg(conn,newUser)
        .then(valasz=>valasz.json())
        .then(valasz=>console.log(valasz.message))
        .catch(err=>console.log(err));

        res.redirect('/login');

    } catch(error) {
        res.redirect('/reg');
    }
});

//passport csomag telepítése --> npm i passport, npm i express-flash,  npm i express-session, npm i passport-local

