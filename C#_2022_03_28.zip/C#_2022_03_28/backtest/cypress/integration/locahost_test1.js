describe ("Localhost test1", ()=>{
            it ("Test1", ()=>{
                cy.visit("http://localhost:8000");
                cy.contains("Valaki fut!");
            });
});