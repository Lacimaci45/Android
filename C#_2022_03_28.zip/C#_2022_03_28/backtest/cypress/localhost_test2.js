describe("Localhost test 2"),()=>{
    it('Get teszt', () => {
        cy.request ("http://localhost:8000/tesztadat").as("testreq");
        cy.get('@testreq').then(res=>{
                expect (res.status).to.eq(200);
                    assert.isArray(res.body, "Ez egy tömb");
        });
    });
};