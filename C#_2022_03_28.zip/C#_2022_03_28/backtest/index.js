const express = require('express');
const app = express();


let tesztadat =[
    {id:1,adat:"Szöveg1"},

    {id:2,adat:"Szöveg2"},

    {id:3,adat:"Szöveg3"},


   
];

app.use(express.json());
app.use(express.urlencoded({extended: true}));

app.listen(8000,()=>{console.log("Valaki fut!")});

app.get('/',(req,res)=>{

    res.send("Valami fut!")

});

//Végpont:
app.get('/tesztadat',(req,res)=>{
        res.json(tesztadat);
});


app.post('/ujadat', ()=>{
    const ujadat ={
        id:req.body.id,
        adat: req.body.adat
    }
});


tesztadat.push(ujadat);
res.status(201).json({message:"Új adat valami"});

app.delete('/torles',(req,res)=>{
    tesztadat = tesztadat.filter(x=>x.id!=req.body.id)
    res.status(200).json({message:"Adat törlve"});
});