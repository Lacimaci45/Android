import{useState,useEffect} from 'react';
import User from './User';

function Users() {

    const [users,setUsers]=useState([]);
    const [page,setPage]=useState(1);
    const [totalPages,setTotalPages]=useState(0);

    useEffect (()=>{
        fetch(`https://reqres.in/api/users?page=${page}`)
        .then(res=>res.json())
        .then(adatok=>{
            setTotalPages(adatok.total_pages);
            setUsers(adatok.data);
        })
        .catch(err=>console.log(err))

    },[]);

 return (
    <div>
        <h2>Adatok száma: {users.length}</h2>
        {
            users.map((elem,index)=>(<User key={index} user={elem}/>))
        }
    </div>
)}

export default Users;