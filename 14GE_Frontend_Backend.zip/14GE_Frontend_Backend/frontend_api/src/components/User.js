

function User({user}) {
  return (
    <div>
        <div>
            <ul>
                <li>
                    {user.first_name} {user.last_name}
                </li>
                <li>
                    {user.email}
                </li>
            </ul>
        </div>
        <div>
            <img src={user.avatar}/>
        </div>
    </div>
  )
}

export default User;