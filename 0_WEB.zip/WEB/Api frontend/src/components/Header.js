

function Header() {
    return (
      <div className="d-flex flex-row justify-content-center">
          <div>
              <h1>Api practice</h1>
          </div>
      </div> 
    )
  }
  
  export default Header;