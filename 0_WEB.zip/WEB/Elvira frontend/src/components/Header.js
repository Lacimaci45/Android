
function Header() {
  return (
    <div className="d-flex flex-row justify-content-center">
        <h1>Elvira menetrend</h1>
    </div>
  )
}

export default Header