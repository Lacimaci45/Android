function Footer({szoveg,email,href}) {
    return (
        <div >
             <a href="Homepage\JS Game\game.html">JS Játék</a>
             <h4>{szoveg}</h4>
             <h4>{email}</h4>
             <h4>{href}</h4>
        </div>
    )
}

export default Footer;