//új adat file --> kiegészítőkbe telepíteni kódolást segítő csomagok: Cypress Snippets, Cypress Helper, Open cypress, Cypress Fixture-IntelliSense

describe("Post teszt",()=>{
    it("Adatküldés teszt",()=>{
        cy.request({
            method: 'POST',
            url: 'http://localhost:8000/ujadat',
            body:{id:4,adat:"Szöveg4"}
        }).as('testreq');
        cy.get('@testreq').then(res=>{
            expect(res.status).to.eq(201);
            expect(res.body).has.property('message','Adat beszúrva!');
        });
    });
});

//npm start --> js_test terminálba / cypress mappa terminál --> npm test --> minden teszt futtatás után meg kell adni
