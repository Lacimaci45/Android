//2-es teszt kódjai 

describe ("Get test",()=>{
    it("Fetch data",()=>{
        cy.request("http://localhost:8000/tesztadat").as('testreq');
        cy.get('@testreq').then(res=>{
            expect(res.status).to.eq(200);
            assert.isArray(res.body, "Rendben van ez a tömb");
        });
    });
});


//Terminálba a teszt parancsok
//npm test --> fontos, hogy új terminált kell nyitni a meglévő mellé mikor indítjuk