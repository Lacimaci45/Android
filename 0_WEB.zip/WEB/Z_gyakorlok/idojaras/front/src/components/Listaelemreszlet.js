function Listaelemreszlet({elem}){

    return(
        <div>
            <p>Hőmérséklet:{elem.homerseklet}</p>
            <p>Szélsebesség:{elem.szelsebesseg}</p>
            <p>Páratartalom:{elem.paratartalom}</p>
        </div>
    );

}

export default Listaelemreszlet;