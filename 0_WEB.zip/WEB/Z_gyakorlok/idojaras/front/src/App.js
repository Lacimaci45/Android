import Header from './components/Header';
import List from './components/List';
import {useState,useEffect} from 'react';
import './App.css';

function App() {
  const ev=2011;
  const [lista,setLista]=useState([]);
  useEffect(()=>{
    fetch(`http://127.0.0.1:8000/ev/${ev}`)
    .then(res=>res.json())
    .then(adatok=>setLista(adatok));
  },[]);


  return (
    <div>
      <Header cim={"Időjárás frontend"} udvozles={"Hello"} />
      <h2>A lista hossza:{lista.length}</h2>
      <List lista={lista} />     
    </div>
  );
}

export default App;
