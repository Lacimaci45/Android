import './App.css';
import Lista from './components/Lista';
import {useState, useEffect} from 'react';
import Valaszto from './components/Valaszto';

function App() {

  const [lista,setLista]=useState([]);
  const [listaMeret,setListaMeret]=useState(5);

  useEffect(()=>{
    fetch(`https://randomuser.me/api/?results=${listaMeret}`)
    .then(res=>res.json())
    .then(adatok=>setLista(adatok.results))
    .catch(err=>console.log(err))
  },[listaMeret]);

  return (
    <div className="App">
      <h1>RandomUser API</h1>  
      <h2>Lista mérete:{lista.length}</h2>
      <Valaszto setListaMeret={setListaMeret} />
      <Lista lista={lista} />
    </div>
  );
}

export default App;
