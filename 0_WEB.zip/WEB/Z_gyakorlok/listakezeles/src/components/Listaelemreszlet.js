function Listaelemreszlet({elem}){
    return (
        <div>
            
            <p>Age:{elem.dob.age}</p>
            <p>State:{elem.location.state}</p>
            <p>Country:{elem.location.country}</p>
            <p>City:{elem.location.city}</p>
            <p>Street:{elem.location.street.name},Number: {elem.location.street.number}</p>
            <p><img src={elem.picture.large}></img></p>
            
        </div>
    );
}

export default Listaelemreszlet;