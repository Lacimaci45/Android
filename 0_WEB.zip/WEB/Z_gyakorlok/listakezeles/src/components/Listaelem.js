import Listaelemreszlet from "./Listaelemreszlet";
import { useState } from "react";

function Listaelem({elem}){

    const [isClicked,setClicked]=useState(false);

    return (
        <div onClick={()=>setClicked(!isClicked)}>

            {/* Node JS comment */} 
            {/*feltétel? tevékenység ha igaz: tevékenység ha hamis*/}

            {isClicked ? 
            <div>
            <p>{elem.name.title}. {elem.name.first} {elem.name.last}</p>
            <Listaelemreszlet elem={elem}/>
            </div>: 
            <p>{elem.name.title}. {elem.name.first} {elem.name.last}</p>}

                        
        </div>
    );
}

export default Listaelem;