import Listaelem from "./Listaelem";

function Lista({lista}){
    return (
        <div>

            {lista.map((elem, index)=>(<Listaelem key={index} elem={elem} />))}

        </div>
    );

}

export default Lista;