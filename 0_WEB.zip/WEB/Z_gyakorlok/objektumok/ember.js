class Ember {
    constructor(nev,lakhely,kor,kep,utvonal){
        this.nev=nev;
        this.lakhely=lakhely;
        this.kor=kor;
        this.kep=utvonal+"/"+kep;
    }

}