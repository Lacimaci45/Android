class Auto {
    constructor(rendszam,tipus,kor){
        this.rendszam=rendszam;
        this.tipus=tipus;
        this.kor=kor;
    }
}
module.exports=Auto;