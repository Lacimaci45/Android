module.exports.osszeadas=function(a,b){
    return (a+b);
}

module.exports.kivonas=function(a,b){
    return (a-b);
}

module.exports.szorzas=(a,b)=>a*b;

module.exports.osztas=function(a,b){
    return (a/b);
}