class Ember {
    constructor(id,nev,kor){
        this.id=id;
        this.nev=nev;
        this.kor=kor;
    }
}
module.exports=Ember