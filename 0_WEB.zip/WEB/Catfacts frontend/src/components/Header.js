
function Header() {
  return (
    <h1 className="text-5xl px-3 py-2 text-amber-50 bg-amber-500">Cat Facts</h1>
  )
}

export default Header