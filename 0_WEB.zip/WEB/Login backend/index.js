const express=require('express');
const cors=require('cors');
const mysql=require('mysql');
const bcrypt=require('bcrypt');
const passport=require('passport');
const flash=require('express-flash');
const session=require('express-session');
const methodOverride=require('method-override');
const {registeruser,getuserbyusername,getuserbyid} =require('./dbrepo');
const initializePassport=require('./passport-config');
const fileUpload = require('express-fileupload');

const fs = require("fs");
const path = require("path");



function checkAuth(req,res,next)    {
    if(req.isAuthenticated()){
        return next();
    }
    res.redirect('/login');
}

function checkNotAuth(req,res,next){
    if(req.isAuthenticated()){
        return res.redirect('/');
    }
    next();
    
}


const conn=mysql.createConnection(
    {
        host:"localhost",
        user:"root",
        password:"",
        database:"userdb"
    }
);

const userss=[{
    id:1,
    username:"user1",
    password:"$2b$10$yHnNWMyy26ASpX3AUq1ObuHm95DBtYH/NE7DyGrUCpLbwxDn6GvCm"
    }
]

initializePassport(passport,conn);


const app=express();
app.use(cors());
app.set('view-engine','ejs');
app.use(express.urlencoded({extended:true}));
app.use(flash());
app.use(session({
    secret:"lof",
    resave:false,
    saveUninitialized:false,
}));
app.use(passport.initialize());
app.use(passport.session());
app.use(methodOverride('_method'));
app.use("/files", express.static(path.join(__dirname,'files')));
app.use(fileUpload());

app.listen(8000,()=>{console.log("Fut a szerver")});

app.get('/',checkAuth,(req,res)=>{
    res.render("index.ejs",{username:req.user.username});
});

app.get('/vedett',checkAuth,(req,res)=>{
    res.send("Ez egy védett erőforrás!");
});

app.post('/kepfeltoltes',checkAuth,async(req,res)=>{
    console.log("Files:"+req.files.kepfajl.name);
    console.log(req.user.username);
    const user=req.user.username;
    
    
    if(req.files){
        console.log("Van fájl");
        const file=req.files.kepfajl;
        const utvonal=__dirname+"/files/"+user+"/"+file.name;
        if(!fs.existsSync(utvonal)){
            fs.mkdirSync(utvonal,{recursive:true});
        }
        file.mv(utvonal+file.name,(err)=>{
            if(err){
            res.status(500).send(err);
            } else {
                return res.send({status:200,message:"Fájl feltöltve"+utvonal});
            }
            
        });


    }
    //res.send(req.body.kepalairas);
});

app.get('/kepfeltoltes',checkAuth,(req,res)=>{
    res.render("picsend.ejs");
});

app.get('/register',checkNotAuth,(req,res)=>{
    res.render('register.ejs');

});

app.get('/login',checkNotAuth,(req,res)=>{
    res.render('login.ejs');
});

app.post('/register',checkNotAuth,async(req,res)=>{

    try {
        const hashedPassword=await bcrypt.hash(req.body.password,10);
        const newuser={
            email:req.body.email,
            username:req.body.username,
            password:hashedPassword
        }
    
        registeruser(conn,newuser).then(valasz=>valasz.json()).then(valasz=>{console.log(valasz.message)}).catch(err=>{console.log(err)});
        res.redirect('/login');
        
    } catch (error) {
        res.redirect('/register');
    }
});

app.post('/login',checkNotAuth,passport.authenticate('local',{
    successRedirect:'/',
    failureRedirect:'/login',
    failureFlash:true
}));

app.get('/getuserbyname/:username',(req,res)=>{
    getuserbyusername(conn,req.params.username).then(user=>res.json(user)).catch(err=>res.send(err));
});

app.delete('/logout',(req,res)=>{
    req.logOut();
    res.redirect('/login');
});

