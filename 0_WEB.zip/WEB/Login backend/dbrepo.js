module.exports.getuserbyid=function(conn,id){
    return new Promise((reject,resolve)=>{
        conn.query("select * from users where id=?",[id],(error,rows)=>{
            if(error){
                reject(error);
            } else {
                resolve(rows);
            }
        })
    });

}

module.exports.getuserbyusername=function(conn,username){
    return new Promise((reject,resolve)=>{
        conn.query("select * from users where username=?",[username],(error,rows)=>{
            if(error){
                reject(error);
            } else {
                console.log("GetuserByName");
                resolve(rows);
            }
        })
    });
}

module.exports.getuserbyusernamenp=async function(conn,username,callback){
    console.log(username);
    conn.query("select * from users where username=?",[username],(error,rows,fields)=>{
        if(error){
            console.log(error);
            return error;
        } else {
            console.log("Vannak adatok "+fields);
           // Object.keys(fields).forEach(function(key) {
                //var field = fields[key];
                //console.log(field);
            //})

            return callback(rows);
        }
    })
}

module.exports.registeruser=function(conn,userdata){
    return new Promise((reject,resolve)=>{
        conn.query("insert into users (email,username,password) values(?,?,?)",
        [
            userdata.email,            
            userdata.username,
            userdata.password
            
        ],
        error=>{
            if(error){
                reject(error);
            } else {
                resolve({status:201,message:"Adat beszúrva"});
            }

        });
    });
}