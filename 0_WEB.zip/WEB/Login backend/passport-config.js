const LocalStrategy=require('passport-local').Strategy;
const bcrypt=require('bcrypt');
const {getuserbyusername,getuserbyid} =require('./dbrepo');


function initialize(passport,conn){
    const authenticateUser=async(username,password,done)=>{
        
        console.log(username);
        
        
            conn.query("select * from users where username=?",[username],(error,rows)=>{
                if(error){
                    return done(error);
                } 
                if(rows.length==0){
                    return done(null,false,{message:"Nincs ilyen felhasználó!"});
                }

                const passcheck=checkPassword(password,rows[0].password);
                user={
                    id:rows[0].id,
                    email:rows[0].email,
                    username:rows[0].username,
                    password:rows[0].password
                }
                console.log("Itt a user:",user);
                if(passcheck){
                    return done(null,user);
                } else{
                    return done(null,false,{message:"A jelszó nem megfelelő!"});
                }

                /*try {
                    if(await bcrypt.compare(password,rows[0].password)){
                        console.log("Jelszó jó");
                        return done(null,user);
                    } else {
                        console.log("Jelszó rossz");
                        return done(null,false,{message:"A jelszó nem megfelelő!"})
                    }
                    
                } catch (error) {
                    return done(error);
                }*/

            });
                        
        
        
       
    

    }
    passport.use(new LocalStrategy({usernameField:'username'},authenticateUser));
    passport.serializeUser((user,done)=>done(null,user.id));
    //passport.deserializeUser((id,done)=>{return done(null,getuserbyid(conn,id))});
    passport.deserializeUser((id,done)=>{
        conn.query("select * from users where id=?",[id],(error,rows)=>{
            if(error){
                return done(error);
            } else {
                return done(null,rows[0]);
            }
        })
        });

}
async function checkPassword(password,userPassword){
    try{
        if(await bcrypt.compare(password,userPassword)){
            return true;
        } else {
            return false;
        }

    } catch(e){
        return done(e);
    }

}
module.exports=initialize;