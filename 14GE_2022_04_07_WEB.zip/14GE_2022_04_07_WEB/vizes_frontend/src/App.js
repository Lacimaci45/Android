//React Responsive felépítése 
//terminal: npx create-react-app ./ npm i react-router-dom@5.3.0
//terminal: npm install -D tailwindcss postcss autoprefixer/ npx tailwindcss init
//terminal: npm i daisyui
//index.css módosítása, postcss.config.js létrehozása, tailwind.config.js

import Header from "./components/Header";
import './index.css';
import Main from "./components/Main";
import Menu from "./components/Menu";
import Vizallas from "./components/Vizallas";
import Varosok from "./components/Varosok";
import {BrowserRouter,Switch,Redirect,Route} from "react-router-dom"


function App() {
  return (
    <div>
      <Header/>
      <BrowserRouter>
      <Menu/>
      <Switch>
        <Route path='/' exact><Main/></Route>
        <Route path='/varosok'><Varosok/></Route>
        <Route path='/vizallas'><Vizallas/></Route>
        <Redirect to={'/'}/>
      </Switch>
      </BrowserRouter>         
    </div>
  );
}

export default App;
