
function Varosok() {
  return (
    <div>Varosok</div>
  )
}

export default Varosok;