
function Vizallas() {
  return (
    <div>Vizallas</div>
  )
}

export default Vizallas;