//csomagok behívása
const express=require('express');
const app=express();

//app.use alkalmazások aktiválása
app.use(express.json());
app.use(express.urlencoded({extended:true}));


//tesztadat lista létrehozása
const tesztadat=[
    {
        id:1,
        adat:"Szöveg1"
    },
    {
        id:2,
        adat:"Szöveg2"
    },
    {
        id:3,
        adat:"Szöveg3"
    }
];

//szerver port + üzenet
app.listen(8000,()=>{console.log("Server is running")});

//végpontok
app.get('/', (req, res)=>{
    res.send("<h1>JavaScript Cypress Test</h1>");
});

//tesztadat végpont létrehozása
app.get('/tesztadat',(req,res)=>{
    res.json(tesztadat);
});

//npm i -save-dev cypress --> telepítése