//csomagok behívása
const express=require('express');
const app=express();

//app.use alkalmazások aktiválása
app.use(express.json());
app.use(express.urlencoded({extended:true}));


//tesztadat lista létrehozása const-al csak egyszer rendelhető --> át kell írni let-re
let tesztadat=[
    {
        id:1,
        adat:"Szöveg1"
    },
    {
        id:2,
        adat:"Szöveg2"
    },
    {
        id:3,
        adat:"Szöveg3"
    }
];

//szerver port + üzenet
app.listen(8000,()=>{console.log("Server is running")});

//végpontok
app.get('/', (req, res)=>{
    res.send("<h1>JavaScript Cypress Test</h1>");
});

//tesztadat végpont létrehozása
app.get('/tesztadat',(req,res)=>{
    res.json(tesztadat);
});

//npm i -save-dev cypress --> telepítése

//új adat hozzáadása végpont
app.post('/ujadat',(req,res)=>{
    const ujadat={
        id:req.body.id,
        adat:req.body.adat,
    }
    tesztadat.push(ujadat);
    res.status(201).json({message:"Adat beszúrva!"});

});

//törlés végpont
app.delete('/torles',(req,res)=>{
    const torolni=req.body.id;
    tesztadat=tesztadat.filter(x=>x.id!=torolni);
    res.status(200).json({message:"Adat törölve!"});
});