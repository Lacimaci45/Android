//1-es teszt kódjai 

describe ("Localhost test 1",()=>{
    it("Local",()=>{
        cy.visit("http://localhost:8000");
        cy.contains("JavaScript Cypress Test");
    });
});

//Terminálba a teszt parancsok
//npm test --> fontos, hogy új terminált kell nyitni a meglévő mellé mikor indítjuk
//npx cypress open --> parancs a terminálba --> grafikusan indul el 
//