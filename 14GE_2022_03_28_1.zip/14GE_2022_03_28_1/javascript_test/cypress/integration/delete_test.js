// delete file
//cyreq + enter --> cy.request létrehozása

describe("Törlés teszt",()=>{
    it("Delete test",()=>{
        cy.request({
            method: 'DELETE',
            url: 'http://localhost:8000/torles',
            body: {id: 2},
        }).as('testreq');
        cy.get('@testreq').then(res=>{
            expect(res.status).to.eq(200);
            expect(res.body).has.property('message','Adat törölve!');
        });
    });
});

//npm start --> js_test terminálba / cypress mappa terminál --> npm test --> minden teszt futtatás után meg kell adni