# vizes_14d
React App A vizes adatbázis alapján
